package Controller;

public interface Controller
{// coooment
   public void execute(String message);
}
