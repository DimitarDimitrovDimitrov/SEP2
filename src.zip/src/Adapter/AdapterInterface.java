package Adapter;

import Model.Messages;
//coooment
public interface AdapterInterface {

	
	public void Write(Messages list);
	public void Read();
}
