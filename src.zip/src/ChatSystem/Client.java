package ChatSystem;

//coooment
public class Client
{
 private String name;
 public Client()
 {
    
 }
 public void setName(String name)
 {
    this.name=name;
 }
 public String getName()
 {
    return name;
 }
}
